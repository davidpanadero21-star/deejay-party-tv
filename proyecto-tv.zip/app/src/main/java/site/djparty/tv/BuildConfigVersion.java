package site.djparty.tv;

import android.content.Context;

/** Versión de la app (para que el juego sepa que va dentro de la app de la tele). */
final class BuildConfigVersion {
    static String nombre(Context c) {
        try { return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName; }
        catch (Exception e) { return "1"; }
    }
}
