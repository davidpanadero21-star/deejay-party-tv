package site.djparty.tv;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

/**
 * Deejay Party para la tele: el juego (djparty.site) a pantalla completa.
 * djparty.site elige solo la conexión que funciona (Cloudflare o la reserva los días de bloqueo),
 * así que cualquier actualización del juego llega sin tocar la app.
 */
public class MainActivity extends Activity {
    static final String INICIO = "https://djparty.site/";
    static final String ERROR = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
        + "<style>body{margin:0;height:100vh;display:flex;align-items:center;justify-content:center;background:#3ccfc8;"
        + "font-family:sans-serif;color:#24124f;text-align:center}div{background:#fff8ec;border:4px solid #24124f;"
        + "border-radius:22px;padding:28px 36px;max-width:520px}h1{margin:0 0 8px}button{margin-top:18px;font-size:22px;"
        + "font-weight:bold;padding:12px 30px;border-radius:999px;border:4px solid #24124f;background:#ff4f9a;color:#fff}"
        + "button:focus{outline:5px solid #ffd23f}</style></head><body><div><h1>Sin conexión</h1>"
        + "<p>Revisa que la tele está conectada a internet.</p>"
        + "<button id='b' autofocus onclick=\"location.href='" + INICIO + "'\">Reintentar</button></div>"
        + "<script>document.getElementById('b').focus()</script></body></html>";

    private WebView web;
    private long ultimoAtras = 0;

    @Override
    protected void onCreate(Bundle estado) {
        super.onCreate(estado);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#3ccfc8"));
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);   // la música suena sin tener que tocar la pantalla
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(s.getUserAgentString() + " DeejayPartyTV/" + BuildConfigVersion.nombre(this));

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) v.loadDataWithBaseURL(INICIO, ERROR, "text/html", "utf-8", null);
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            // la tele no usa el micrófono (el chat de voz va en los móviles)
            @Override
            public void onPermissionRequest(PermissionRequest r) { r.deny(); }
        });

        setContentView(web);
        if (estado != null) web.restoreState(estado);
        else web.loadUrl(INICIO);
        web.requestFocus();
        pantallaCompleta();
    }

    private void pantallaCompleta() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }

    @Override
    public void onWindowFocusChanged(boolean foco) {
        super.onWindowFocusChanged(foco);
        if (foco) pantallaCompleta();
    }

    @Override
    public boolean onKeyDown(int tecla, KeyEvent ev) {
        if (tecla == KeyEvent.KEYCODE_BACK) {
            if (web.canGoBack()) { web.goBack(); return true; }
            long ahora = System.currentTimeMillis();
            if (ahora - ultimoAtras < 2500) { finish(); return true; }
            ultimoAtras = ahora;
            Toast.makeText(this, "Pulsa atrás otra vez para salir de Deejay Party", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onKeyDown(tecla, ev);
    }

    @Override protected void onSaveInstanceState(Bundle b) { super.onSaveInstanceState(b); web.saveState(b); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
    @Override protected void onPause() { web.onPause(); super.onPause(); }
    @Override protected void onDestroy() { web.destroy(); super.onDestroy(); }
}
